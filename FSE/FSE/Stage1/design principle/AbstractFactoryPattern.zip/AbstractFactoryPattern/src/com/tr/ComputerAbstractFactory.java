package com.tr;

public interface ComputerAbstractFactory {

	public Computer createComputer();

}

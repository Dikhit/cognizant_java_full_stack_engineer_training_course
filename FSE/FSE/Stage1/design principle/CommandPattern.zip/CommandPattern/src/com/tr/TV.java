package com.tr;

public class TV extends Receiver{
    
    public String toString(){
        return this.getClass().getSimpleName();
    }
}
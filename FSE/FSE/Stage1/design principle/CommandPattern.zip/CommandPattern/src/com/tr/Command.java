package com.tr;

public interface Command {
    void execute();
}
package com.tr;

 // an observe that can be registered and receive notifications
public interface LongWordsObserver {
    void notify(WordEvent event);
}
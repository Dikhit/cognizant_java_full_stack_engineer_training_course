package com.tr;

 import java.util.List;
import java.util.ArrayList;

/* Define the contract for communication between Colleagues. 
   Implementation is left to ConcreteMediator */
public interface Mediator{
    void register(Colleague colleague);
    void unregister(Colleague colleague);
}

package com.tr;

import java.util.ArrayList;
import java.util.List;

/* Act as a central hub for communication between different Colleagues. 
Notifies all Concrete Colleagues on occurrence of an event
*/
public class NetworkMediator implements Mediator{
 List<Colleague> colleagues = new ArrayList<Colleague>();
 
 public NetworkMediator(){
 
 }
 
 public void register(Colleague colleague){
     colleagues.add(colleague);
     for (Colleague other : colleagues){
         if ( other != colleague){
             other.receiveRegisterNotification(colleague);
         }
     }
 }
 public void unregister(Colleague colleague){
     colleagues.remove(colleague);
     for (Colleague other : colleagues){
         other.receiveUnRegisterNotification(colleague);
     }
 }
}

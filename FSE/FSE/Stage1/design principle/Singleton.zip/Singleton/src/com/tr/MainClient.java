package com.tr;

public class MainClient {

	public static void main(String[] args) {
		LazyInitialization lazy1=LazyInitialization.getInstance();
		LazyInitialization lazy2=LazyInitialization.getInstance();
		System.out.println("Lazy 1:"+lazy1.hashCode());
		System.out.println("Lazy 2:"+lazy2.hashCode());

		
		EagerInitializedSingleton eager1=EagerInitializedSingleton.getInstance();
		EagerInitializedSingleton eager2=EagerInitializedSingleton.getInstance();
		
		System.out.println("Eager 1:"+eager1.hashCode());
		System.out.println("Eager 2:"+eager2.hashCode());

	}

}

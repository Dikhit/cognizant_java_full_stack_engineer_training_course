package com.tr;

import java.util.Objects;

public class LazyInitialization {

    private static LazyInitialization INSTANCE = null;

    private LazyInitialization() {
    }

    public synchronized static LazyInitialization getInstance() {
        if (Objects.isNull(INSTANCE)) {
            INSTANCE = new LazyInitialization();
        }
        return INSTANCE;
    }
    
    @Override
    protected Object clone() throws CloneNotSupportedException {
    	// TODO Auto-generated method stub
    	throw new CloneNotSupportedException("No Cloning");
    }
}
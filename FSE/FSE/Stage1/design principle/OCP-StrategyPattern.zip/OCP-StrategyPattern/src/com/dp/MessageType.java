package com.dp;

public enum MessageType {
	TEXT, BYTE, XML;
}
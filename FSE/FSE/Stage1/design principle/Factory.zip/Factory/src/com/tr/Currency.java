package com.tr;

public interface Currency {
    String getSymbol();
}